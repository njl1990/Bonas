
1.login
http://<host>:<port>/ci/dlgin/?device_id=<device_id>&address=<id:port>


2.logout
http://<host>:<port>/ci/dlgout/?device_id=<device_id>


from django.apps import AppConfig


class CiConfig(AppConfig):
    name = 'ci'
